
Instructions for project 2:

1. Download and unzip all the code files.
2. I recommend using Google Colab as that is what I used and it imports everything for you.
3. In the toolbar of Colab, select runtime and select the 'run all' option to run all the cells.
4. Make sure you are running everything after importing the nessecary datasets (I have used the 4 datasets for MNIST from Github as the website is down and the Kaggle Monkey Dataset as the project requested).
5. The code is divided into two files - one for task 1(mnist_code.ipynb) and one for task 2(Monkey_code.ipynb).